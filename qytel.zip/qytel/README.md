<<<<<<< HEAD
# QYtel
电信实习蓝鲸云
=======
开发框架2.0使用说明：https://docs.bk.tencent.com/blueapps/USAGE.html
>>>>>>> helloworld
